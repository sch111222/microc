﻿请将文件拷贝到c:\fsharp

将下面两个路径添加到你的Path

c:\fsharp\FsLexYacc.7.0.6\build
c:\fsharp\FSharp.Compiler.Tools.4.1.27\tools

fsharp 命令行解释器fsi
fsharp 编译器 fsc

#quit;; 退出  fsi




参考 vscode,  进行IDE配置， alt+enter 将当前选中行发送到 命令窗口。
 
	0. 安装 VSCode。
	1. 配置 ionide 插件 vscode.fsharp.ionide.png
	2. 配置 fsharp 路径 vscode.fsharp.config.path.png